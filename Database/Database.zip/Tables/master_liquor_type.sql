insert into itbp_clms.master_liquor_type (id, liquor_type, created_by, creation_time)
values  (1, 'Single Malt', 35, '2021-10-23 17:04:04'),
        (2, 'Whisky', 35, null),
        (3, 'Vodka', 35, null),
        (4, 'Scotch', 35, null),
        (5, 'Champange', 35, null),
        (6, 'Gin', 35, '2021-10-23 15:07:06'),
        (7, 'Rum', 35, '2021-10-23 17:07:45');