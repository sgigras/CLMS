insert into itbp_clms.mess_type (id, mess_type)
values  (1, 'Officer Mess');