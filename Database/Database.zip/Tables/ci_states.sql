insert into itbp_clms.ci_states (id, name, country_id)
values  (1, 'Maharashtara', 1),
        (2, 'Delhi', 1),
        (3, 'Punjab', 1);