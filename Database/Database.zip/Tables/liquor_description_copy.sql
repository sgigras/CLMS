insert into itbp_clms.liquor_description_copy (id, liquor_description, liquor_image, liquor_brand_id, liquor_bottle_size_id, liquor_type_id, liquor_ml_id, creation_time, created_by, modification_time, modified_by, liquor_descriptioncol)
values  (1, 'Heneken', '.\\/uploads\\/liquor_image\\/20211029\\/heineken1.png', '8', 2, '6', '4', '2021-10-29 23:25:34', 197, null, null, null),
        (2, 'BLACK', 'assets/dist/img/product-img/oldmonk.jpg', '2', 2, '2', '2', null, null, null, null, null),
        (3, 'STRONG', 'assets/dist/img/product-img/hennessy.jpeg', '3', 3, '3', '1', null, null, null, null, null),
        (4, 'Black', 'assets/dist/img/product-img/absolut.jpg', '4', 2, '2', '3', null, null, null, null, null),
        (5, 'Orange', 'assets/dist/img/product-img/polikov.jpg', '6', 1, '2', '3', null, null, null, null, null),
        (7, 'a', '.\\/uploads\\/liquor_image\\/20211029\\/bsflogo27.png', '2', 3, '4', '4', '2021-10-29 19:48:08', 197, null, null, null),
        (8, 'test', '.\\/uploads\\/liquor_image\\/20211029\\/bsflogo28.png', '3', 3, '5', '3', '2021-10-29 19:48:37', 197, null, null, null),
        (9, 'adsfsdfasdfasdf', '.\\/uploads\\/liquor_image\\/20211029\\/bluemoon2.jpeg', '3', 2, '4', '3', '2021-10-29 20:09:19', 197, null, null, null),
        (10, 'beer description', '.\\/uploads\\/liquor_image\\/20211029\\/heineken2.png', '3', 2, '3', '4', '2021-10-29 23:26:04', 197, null, null, null),
        (11, 'BELGIAN WHITE', '.\\/uploads\\/liquor_image\\/20211029\\/bluemoon5.jpeg', '1', 2, '2', '4', '2021-10-29 23:21:59', 197, null, null, null),
        (12, 'NEW LIQUOR TEST', '.\\/uploads\\/liquor_image\\/20211029\\/heineken3.png', '4', 3, '5', '1', '2021-10-29 23:28:20', 197, null, null, null);