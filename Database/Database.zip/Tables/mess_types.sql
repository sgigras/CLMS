insert into itbp_clms.mess_types (id, mess_type)
values  (1, 'ORS Mess'),
        (2, 'SOS Mess'),
        (3, 'Officer Mess');