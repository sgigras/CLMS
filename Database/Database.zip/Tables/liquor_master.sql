insert into itbp_clms.liquor_master (ID, LIQUOR_TYPE, LIQUOR_BRAND, MOQ, UNIT_IN_LOT_SIZE, REMARKS, INSERT_TIME)
values  (0, 'RUM', null, null, null, null, '2021-10-22 11:41:15'),
        (1, 'WHISKY', 'ROYAL STAG', 64646, 3, 'LIQUOR', '2021-10-21 22:08:05'),
        (2, 'dvbb', null, null, null, null, '2021-10-22 10:36:15');