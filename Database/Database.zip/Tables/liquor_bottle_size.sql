insert into itbp_clms.liquor_bottle_size (id, bottle_size, created_by, creation_time)
values  (1, 'Miniature', null, null),
        (2, 'Full', null, null),
        (3, 'Quater', null, null);