insert into itbp_clms.alerts_log (id, alert_code, alert_type, receiver_mailid, sender_mailid, subject, msg_body, cc_receiver_mailid, mobileno, fcm, is_alert_sent, is_alert_delivered, insert_time, attachment_path, is_mail_last_attempt)
values  (1, 'OTP', 'm', 'harish.manoharan@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">642310</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-10-29 11:31:20', null, 0),
        (2, 'OTP', 'm', 'harish.manoharan@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">029739</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-10-29 18:18:17', null, 0),
        (3, 'OTP', 'm', 'harish.manoharan@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">641681</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-10-29 18:19:59', null, 0),
        (4, 'OTP', 'm', '99SamiranSarkar@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">468450</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-10-30 15:17:50', null, 0),
        (5, 'OTP', 'm', 'spbaluni@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">035517</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-10-30 16:36:41', null, 0),
        (6, 'OTP', 'm', 'pr.kantharaju@gmail.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">338956</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-30 17:09:08', null, 0),
        (7, 'OTP', 'm', 'pr.kantharaju@gmail.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">088650</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-30 17:14:52', null, 0),
        (8, 'OTP', 'm', 'pr.kantharaju@gmail.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">392501</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-30 17:20:13', null, 0),
        (9, 'OTP', 'm', 'khanjamil897@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">646650</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-30 21:14:21', null, 0),
        (10, 'OTP', 'm', 'nairss68@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">796268</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 06:54:46', null, 0),
        (11, 'OTP', 'm', 'NOTAVAILABLE@hotmail.COM', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">220279</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 09:09:06', null, 0),
        (12, 'OTP', 'm', 'csinghof555@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">541382</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 11:52:06', null, 0),
        (13, 'OTP', 'm', 'csinghof555@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">480303</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 11:55:08', null, 0),
        (14, 'OTP', 'm', 'notavailable@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">520710</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 12:00:26', null, 0),
        (15, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">878132</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 12:10:29', null, 0),
        (16, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">574833</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 12:11:06', null, 0),
        (17, 'OTP', 'm', 'pratik.sonare@bsf.nic.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">249413</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 12:33:40', null, 0),
        (18, 'OTP', 'm', 'pratik.sonare@bsf.nic.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">324234</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 12:43:28', null, 0),
        (19, 'OTP', 'm', 'skashyap1452@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">179200</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 14:46:35', null, 0),
        (20, 'OTP', 'm', 'skashyap1452@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">708217</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 14:54:31', null, 0),
        (21, 'OTP', 'm', 'pratik.sonare@bsf.nic.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">158928</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 16:44:43', null, 0),
        (22, 'OTP', 'm', 'pratik.sonare@bsf.nic.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">595999</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 16:45:00', null, 0),
        (23, 'OTP', 'm', 'pratik.sonare@bsf.nic.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">533691</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 17:13:34', null, 0),
        (24, 'OTP', 'm', 'pratik.sonare@bsf.nic.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">206735</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 18:08:40', null, 0),
        (25, 'OTP', 'm', 'pratik.sonare@bsf.nic.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">160039</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 18:10:48', null, 0),
        (26, 'OTP', 'm', 'pratik.sonare@bsf.nic.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">907776</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 18:28:30', null, 0),
        (27, 'OTP', 'm', 'pratik.sonare@bsf.nic.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">527066</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 18:31:09', null, 0),
        (28, 'OTP', 'm', 'pratik.sonare@bsf.nic.in', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">447059</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website http://electro.aniruddhagps.com<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-10-31 18:33:38', null, 0),
        (29, 'OTP', 'm', 'nairss68@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">489343</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', null, '2021-11-01 02:13:18', null, 0),
        (30, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">634490</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 11:56:53', null, 0),
        (31, 'OTP', 'm', 'kanwarbsf@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">361139</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 13:16:56', null, 0),
        (32, 'OTP', 'm', 'NOT@hotmail.COM', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">250761</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 14:05:02', null, 0),
        (33, 'OTP', 'm', 'nihalsingh0293@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">755907</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 14:11:10', null, 0),
        (34, 'OTP', 'm', 'nihalsingh0293@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">954223</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 14:11:24', null, 0),
        (35, 'OTP', 'm', 'pbiswas20@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">811136</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 14:13:51', null, 0),
        (36, 'OTP', 'm', 'bhagvansingh144@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">530913</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 14:21:05', null, 0),
        (37, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">415111</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 16:07:58', null, 0),
        (38, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">271098</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 16:08:42', null, 0),
        (39, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">532717</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 16:09:04', null, 0),
        (40, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">931853</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 16:10:09', null, 0),
        (41, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">494985</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 16:29:19', null, 0),
        (42, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">906728</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 16:31:50', null, 0),
        (43, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">982420</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 16:36:40', null, 0),
        (44, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">106327</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'y', 'y', '2021-11-01 16:37:27', null, 0),
        (45, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">906097</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-11-01 16:58:09', null, 0),
        (46, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">941310</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-11-01 16:59:51', null, 0),
        (47, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">053239</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-11-01 17:01:34', null, 0),
        (48, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">125416</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-11-09 12:32:38', null, 0),
        (49, 'OTP', 'm', 'tapan.tripathi@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">829393</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-11-12 10:26:17', null, 0),
        (50, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">562387</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-11-12 10:46:04', null, 0),
        (51, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">171484</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-11-12 10:53:19', null, 0),
        (52, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">654938</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-11-12 11:30:06', null, 0),
        (53, 'OTP', 'm', 'glmeena6bnbsf@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">713075</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-11-15 15:24:11', null, 0),
        (54, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">676214</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-06 11:26:28', null, 0),
        (55, 'OTP', 'm', 'prathmesh@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">538196</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 11:29:11', null, 0),
        (56, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">216543</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 16:48:20', null, 0),
        (57, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">105975</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 16:54:21', null, 0),
        (58, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">187219</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 16:55:21', null, 0),
        (59, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">171524</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 16:58:44', null, 0),
        (60, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">216617</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 16:58:53', null, 0),
        (61, 'OTP', 'm', 'prathmesh@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">830934</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 17:02:28', null, 0),
        (62, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">918569</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 17:02:45', null, 0),
        (63, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">198380</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 17:05:45', null, 0),
        (64, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">773822</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 17:07:44', null, 0),
        (65, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">867054</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 18:19:08', null, 0),
        (66, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">020360</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-07 18:28:27', null, 0),
        (67, 'OTP', 'm', 'prathmesh@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">615757</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-08 12:04:29', null, 0),
        (68, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">539795</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-08 12:05:13', null, 0),
        (69, 'OTP', 'm', 'prathmesh@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">507954</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-08 12:07:54', null, 0),
        (70, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">173221</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-08 12:10:08', null, 0),
        (71, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">472237</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-08 12:14:26', null, 0),
        (72, 'OTP', 'm', 'prathmesh@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">967316</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-08 12:34:27', null, 0),
        (73, 'OTP', 'm', 'prathmesh@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">103713</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-08 14:04:31', null, 0),
        (74, 'OTP', 'm', 'prathmesh@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">623135</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-08 14:22:26', null, 0),
        (75, 'OTP', 'm', 'prathmesh@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">272339</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-08 16:01:13', null, 0),
        (76, 'OTP', 'm', 'prathmesh@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">058851</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-08 16:21:59', null, 0),
        (77, 'OTP', 'm', 'prathmesh@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">754539</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-08 16:46:25', null, 0),
        (78, 'OTP', 'm', 'prathmesh@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">371239</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-10 10:52:22', null, 0),
        (79, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">938946</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-10 11:27:31', null, 0),
        (80, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">151277</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-13 10:59:09', null, 0),
        (81, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">725778</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-13 11:09:23', null, 0),
        (82, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">167303</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-13 11:10:40', null, 0),
        (83, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">015711</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-15 17:23:20', null, 0),
        (84, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">444355</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-15 17:38:55', null, 0),
        (85, 'OTP', 'm', 'snehal@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">428441</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-23 11:36:59', null, 0),
        (86, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">359746</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-27 15:44:30', null, 0),
        (87, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">853061</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-27 15:49:05', null, 0),
        (88, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">689790</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-27 15:52:20', null, 0),
        (89, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">403680</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-27 15:53:39', null, 0),
        (90, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">961955</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-27 15:57:07', null, 0),
        (91, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">709764</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-27 15:58:13', null, 0),
        (92, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">551138</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-27 16:29:47', null, 0),
        (93, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">822805</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-27 16:30:26', null, 0),
        (94, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">484911</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-28 10:25:10', null, 0),
        (95, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">604297</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-28 10:25:57', null, 0),
        (96, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">485187</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-28 10:26:53', null, 0),
        (97, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">202637</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-28 10:33:16', null, 0),
        (98, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">780013</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-28 10:55:11', null, 0),
        (99, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">007797</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-28 10:58:27', null, 0),
        (100, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">362059</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-28 16:30:21', null, 0),
        (101, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">887449</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2021-12-28 16:33:03', null, 0),
        (102, 'OTP', 'm', 'nairss68@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">600551</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-06-07 17:24:12', null, 0),
        (103, 'OTP', 'm', 'nairss68@hotmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">334974</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-06-07 17:28:28', null, 0),
        (104, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">226809</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-06-10 17:57:11', null, 0),
        (105, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">512762</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-06-10 17:58:24', null, 0),
        (106, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">888101</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-06-10 18:02:47', null, 0),
        (107, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">520941</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-06-10 18:08:17', null, 0),
        (108, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">875928</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-06-10 18:15:29', null, 0),
        (109, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">042852</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-27 22:49:31', null, 0),
        (110, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">110684</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-27 22:54:05', null, 0),
        (111, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">878872</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-27 22:54:55', null, 0),
        (112, 'OTP', 'm', 'bsf@gmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">368111</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-27 23:19:48', null, 0),
        (113, 'OTP', 'm', 'bsf@gmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">618974</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-27 23:24:03', null, 0),
        (114, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">069546</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 02:35:51', null, 0),
        (115, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">607418</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 03:10:23', null, 0),
        (116, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">575953</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 03:54:19', null, 0),
        (117, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">221888</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 03:58:34', null, 0),
        (118, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">305689</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 04:02:49', null, 0),
        (119, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">221002</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 04:02:49', null, 0),
        (120, 'OTP', 'm', 'bsf@gmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">333195</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 04:31:36', null, 0),
        (121, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">240167</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 06:10:34', null, 0),
        (122, 'OTP', 'm', 'ujwal.jain@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">453677</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 06:14:52', null, 0),
        (123, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">259341</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 06:14:52', null, 0),
        (124, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">780385</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 06:19:07', null, 0),
        (125, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">544618</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 06:23:26', null, 0),
        (126, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">018455</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 15:41:54', null, 0),
        (127, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">331210</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 16:24:23', null, 0),
        (128, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">199218</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 19:08:07', null, 0),
        (129, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">020192</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-07-28 19:15:42', null, 0),
        (130, 'OTP', 'm', 'chaudharyraman88@gmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">382375</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-08-02 11:44:28', null, 0),
        (131, 'OTP', 'm', 'chaudharyraman88@gmail.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">782004</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-08-02 14:48:51', null, 0),
        (132, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">455789</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-08-02 14:55:34', null, 0),
        (133, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">908444</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-08-02 15:02:57', null, 0),
        (134, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">451786</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-08-02 15:14:22', null, 0),
        (135, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">283234</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-08-02 15:16:57', null, 0),
        (136, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">114660</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-08-02 15:18:13', null, 0),
        (137, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">752065</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-08-02 15:20:34', null, 0),
        (138, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">966184</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-08-02 15:27:24', null, 0),
        (139, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">376321</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 17:04:21', null, 0),
        (140, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">682563</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 17:04:27', null, 0),
        (141, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">493266</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 17:04:28', null, 0),
        (142, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">564965</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 17:04:29', null, 0),
        (143, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">015169</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 17:04:31', null, 0),
        (144, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">981261</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 17:05:01', null, 0),
        (145, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">185129</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 17:10:02', null, 0),
        (146, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">221459</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 17:17:20', null, 0),
        (147, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">235411</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 17:20:02', null, 0),
        (148, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">355600</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 17:20:36', null, 0),
        (149, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">310731</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 18:03:46', null, 0),
        (150, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">083690</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 18:07:24', null, 0),
        (151, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">955810</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 18:15:25', null, 0),
        (152, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">986688</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 18:24:51', null, 0),
        (153, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">080462</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 18:29:06', null, 0),
        (154, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">758800</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 18:30:57', null, 0),
        (155, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">438109</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 18:33:41', null, 0),
        (156, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">507816</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 18:38:21', null, 0),
        (157, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">395702</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 18:42:46', null, 0),
        (158, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">255151</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 18:51:57', null, 0),
        (159, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">432305</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 18:58:45', null, 0),
        (160, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">449243</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 19:02:02', null, 0),
        (161, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">294331</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 19:03:47', null, 0),
        (162, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">832815</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 19:13:51', null, 0),
        (163, 'OTP', 'm', 'sanjiv@aniruddhagps.com', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">517008</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-09-17 19:14:04', null, 0),
        (164, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">031633</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-11-04 14:33:09', null, 0),
        (165, 'OTP', 'm', '', 'noreply@aniruddhagps.com', 'OTP FOR REGISTRATION', 'Dear User, <br><br>To complete user registration enter OTP as shown below.<br>
		    <table style="width:100%;" border="0" align="center" cellpadding="10" cellspacing="0" id = "FIRST">
				<tr height="37px;">
                    <th colspan= "2" style = "font: bold 13px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72;border-right: 1px solid #C1DAD7; border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;font-weight:bold;"><center>USER REGISTRATION </center></th>
                </tr>
				<tr>
                    <th style = "font: bold 11px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; color: #4f6b72; border-bottom: 1px solid #C1DAD7;border-top: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;letter-spacing: 2px;text-transform: uppercase;padding: 6px 6px 6px 12px;background: #CAE8EA  no-repeat; text-align:left;"><strong>OTP</strong></th>
                    <td style = "padding: 6px 6px 6px 12px;border-bottom: 1px solid #C1DAD7;border-left: 1px solid #C1DAD7;border-top: 0;font:12px Trebuchet MS, Verdana, Arial, Helvetica, sans-serif; border-right: 1px solid #C1DAD7;">080978</td>
                </tr>
                </table>
			<br>To Know More Go To Our Website https://server.aniruddhagps.in/bsfdev/CLMS/admin<br>This is an auto generated mail. Please do not reply back to this.<br><br><br>Thanks<br>Aniruddha Telemetry Systems', null, null, null, 'n', null, '2022-11-04 14:35:03', null, 0);