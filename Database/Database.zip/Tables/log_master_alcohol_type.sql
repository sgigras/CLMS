insert into itbp_clms.log_master_alcohol_type (id, master_alcohol_type_id, alcohol_type, created_by, creation_time)
values  (1, null, 'BRANDY', 35, '2021-10-23 15:07:07'),
        (2, 1, 'SODA', 35, '2021-10-23 15:13:51'),
        (3, 1, 'COLA', 35, '2021-10-23 16:17:24'),
        (4, 1, 'KINGFISHER', 35, '2021-10-23 16:59:50'),
        (5, 1, 'BAGPIPER', 35, '2021-10-23 17:04:04'),
        (6, null, '', 35, '2021-10-23 17:04:55'),
        (7, 7, 'kingfisher', 35, '2021-10-23 17:07:45');