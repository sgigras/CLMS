insert into itbp_clms.states_liquor_margin (id, stateid, liquortypeid, amount)
values  (1, 26, 3, 3.00),
        (2, 26, 4, 3.00),
        (3, 26, 1, 2.00),
        (4, 28, 4, 3.00),
        (5, 26, 2, 2.00),
        (6, 26, 5, 1.00),
        (7, 4, 7, 3.00),
        (8, 2, 5, 1.00),
        (9, 1, 10, 10.00);