insert into itbp_clms.clms_force (id, force_code, force_name)
values  (1, 'BSF', 'Border Security Force'),
        (2, 'ITBP', 'Indo Tibetan Border Police'),
        (3, 'AR', 'Assam Rifles'),
        (4, 'CISF', 'Central Industrial Security Force'),
        (5, 'NSG', 'National Security Guard'),
        (6, 'SSB', 'Shastra Seema Bal'),
        (7, 'CRPF', 'Central Reserve Police Force');