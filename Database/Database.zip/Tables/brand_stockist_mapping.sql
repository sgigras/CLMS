insert into itbp_clms.brand_stockist_mapping (id, entity_id, brand_id, created_by, creation_time, updated_by, updation_time, is_active)
values  (18, 379, '7,9,159,24,26,28', null, '0000-00-00 00:00:00', null, null, null),
        (20, 381, '5,6,7,9', null, '0000-00-00 00:00:00', null, null, null),
        (23, 382, '2,4,6,9,11,36,12', null, '0000-00-00 00:00:00', null, null, null),
        (24, 20, '2,13,21', null, '0000-00-00 00:00:00', null, null, null),
        (25, 9, '10', null, '0000-00-00 00:00:00', null, null, null),
        (26, 10, '9', null, '0000-00-00 00:00:00', null, null, null),
        (27, 46, '7,9,10', null, '0000-00-00 00:00:00', null, null, null);