insert into itbp_clms.nok_relationship (id, relationship_type)
values  (1, 'Father'),
        (2, 'Mother'),
        (3, 'Son'),
        (4, 'Daughter'),
        (5, 'Brother'),
        (6, 'Sister');