insert into itbp_clms.file_upload (id, img_path, uploaded_by, creation_time)
values  (1, './uploads/driver/Screenshot_(1).png', null, '2021-10-27 13:19:33'),
        (2, './uploads/driver/Screenshot_(5).png', null, '2021-10-27 13:21:18'),
        (3, './uploads/liquor_image/Screenshot_(4).png', null, '2021-10-27 13:46:14');