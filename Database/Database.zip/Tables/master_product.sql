insert into itbp_clms.master_product (id, product_name, product_image, product_type, creation_time, created_by)
values  (1, 'Poliakov', 'polikov.jpg', 'Vodka', '2021-10-22 22:53:00', 1),
        (2, 'Jameson', 'wisky.jpg', 'Whisky', '2021-10-22 22:53:00', 1),
        (3, 'Old Monk', 'oldmonk.jpg', 'Rum', '2021-10-22 22:53:00', 1),
        (4, 'Jack Daniels', 'jackdaniels.jpg', 'Whisky', '2021-10-22 22:53:00', 1),
        (5, 'Smirnoff', 'smirnoff.jpg', 'Vodka', '2021-10-22 22:53:00', 1),
        (6, 'Heineken', 'hienken_vodka.jpg', 'Vodka', '2021-10-22 22:53:00', 1),
        (7, 'Absolut', 'absolut.jpg', 'Vodka', '2021-10-22 22:53:00', 1),
        (8, 'Black Label', 'black_label.jpg', 'Whisky', '2021-10-22 22:53:00', 1),
        (9, 'White Mischief', 'white_mischief.jpg', 'Vodka', '2021-10-22 22:53:00', 1),
        (10, 'Hennessy', 'hennessy.jpg', 'Cognac', '2021-10-22 22:53:00', 1);