insert into itbp_clms.user_token (id, token, username, insert_time)
values  (1, 'gCuTKHcs7HC8tq6WW1fqB7alEIu4AmuX2cDpOn82UHwrp35pES', '123478956', null),
        (2, 'LwciOv3r7EpJ88NNixtweY2gXmU2atA1Z5nsWCEuwTWdUp02ev', '77777777', null),
        (3, '4xuJmQ3pO7QA9fyw1jYBWyjBc1btKSlnn326hNw1i37hcRhE4O', '077010825', null),
        (4, 's8r2szQn6W0ooe25Twny72LtB6gSQX6w4cZ4s2UjKIn5U51M2f', '23456789', null);