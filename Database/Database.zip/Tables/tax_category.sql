insert into itbp_clms.tax_category (id, tax_category, created_by, created_at, is_active)
values  (1, 'PrePaid', '240', null, 1),
        (2, 'PostPaid1', '240', null, 1),
        (3, 'PostPaid2', '240', null, 1),
        (4, 'PostPaid3', '240', null, 1);