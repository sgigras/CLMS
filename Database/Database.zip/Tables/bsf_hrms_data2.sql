insert into itbp_clms.bsf_hrms_data2 (id, irla, name, mobile_no, date_of_birth, rank, present_appoitment, status, location_name, district_name, state_name, email_id)
values  (1, 87654321, 'ATS', 9876543234, '1998-12-11', 'AC', 'DC', 'SERVING', 'Delhi', 'New Delhi', 'Delhi', 'ats@gmail.com'),
        (2, 12345678, 'ATS', 1234567890, '1997-11-13', 'AC', 'DC', 'SERVING', 'GURGAON', 'NOIDA', 'DELHI', 'tset@gmail.com'),
        (3, 87654321, 'ATS', 9876543234, '1998-12-11', 'AC', 'DC', 'SERVING', 'Delhi', 'New Delhi', 'Delhi', 'ats@gmail.com'),
        (4, 12345678, 'ATS', 1234567890, '1997-11-13', 'AC', 'DC', 'SERVING', 'GURGAON', 'NOIDA', 'DELHI', 'tset@gmail.com'),
        (5, 87654321, 'ATS', 9876543234, '1998-12-11', 'AC', 'DC', 'SERVING', 'Delhi', 'New Delhi', 'Delhi', 'ats@gmail.com'),
        (6, 12345678, 'ATS', 1234567890, '1997-11-13', 'AC', 'DC', 'SERVING', 'GURGAON', 'NOIDA', 'DELHI', 'tset@gmail.com'),
        (7, 87654321, 'ATS', 9876543234, '1998-12-11', 'AC', 'DC', 'SERVING', 'Delhi', 'New Delhi', 'Delhi', 'ats@gmail.com'),
        (8, 12345678, 'ATS', 1234567890, '1997-11-13', 'AC', 'DC', 'SERVING', 'GURGAON', 'NOIDA', 'DELHI', 'tset@gmail.com'),
        (9, 87654321, 'ATS', 9876543234, '1998-12-11', 'AC', 'DC', 'SERVING', 'Delhi', 'New Delhi', 'Delhi', 'ats@gmail.com'),
        (10, 12345678, 'ATS', 1234567890, '1997-11-13', 'AC', 'DC', 'SERVING', 'GURGAON', 'NOIDA', 'DELHI', 'tset@gmail.com'),
        (11, 87654321, 'ATS', 9876543234, '1998-12-11', 'AC', 'DC', 'SERVING', 'Delhi', 'New Delhi', 'Delhi', 'ats@gmail.com'),
        (12, 12345678, 'ATS', 1234567890, '1997-11-13', 'AC', 'DC', 'SERVING', 'GURGAON', 'NOIDA', 'DELHI', 'tset@gmail.com');