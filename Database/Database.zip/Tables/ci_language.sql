insert into itbp_clms.ci_language (id, name, short_name, status, created_at)
values  (2, 'English', 'en', 1, '2019-09-16 01:13:17'),
        (3, 'French', 'fr', 1, '2019-09-16 08:11:08'),
        (5, 'arbic', 'ar', 1, '2022-08-23 10:19:00');