insert into itbp_clms.brewery_order (id, brewery_id, brewery_order_code, approval_status, approval_from, approved_by, approved_time, created_by, creation_time, modification_time, modified_by, remarks)
values  (1, 1, '8DYOL554', 'P', null, null, '2023-01-23 16:29:12', 229, '2023-01-23 16:29:12', null, null, null),
        (2, 2, 'NTIQ270B', 'P', null, null, '2023-01-24 20:29:02', 229, '2023-01-24 20:29:02', null, null, null),
        (3, 2, 'W70DV2XB', 'P', null, null, '2023-01-24 22:03:33', 229, '2023-01-24 22:03:33', null, null, null),
        (4, 2, 'AF00ZLGF', 'P', null, null, '2023-01-24 22:09:43', 229, '2023-01-24 22:09:43', null, null, null),
        (5, 2, '2UYO11N1', 'P', null, null, '2023-01-24 22:10:54', 229, '2023-01-24 22:10:54', null, null, null),
        (6, 2, 'DN66L6KX', 'P', null, null, '2023-01-25 08:00:48', 229, '2023-01-25 08:00:48', null, null, null),
        (7, 2, '4HWOYPTV', 'A', null, 229, '2023-01-25 08:56:23', 229, '2023-01-25 08:06:02', '2023-01-25 08:56:23', 229, 'Test Approved'),
        (8, 2, 'C1MJU6GQ', 'P', null, null, '2023-01-25 08:08:47', 229, '2023-01-25 08:08:47', null, null, null);