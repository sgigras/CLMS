insert into itbp_clms.liquor_ml_description (id, liquor_description_id, liquor_ml_id, liquor_bottle_id, creation_time, created_by)
values  (1, 1, 1, 2, '2021-10-26 15:10:47', null),
        (6, 2, 2, 1, '2021-10-26 15:11:00', null);