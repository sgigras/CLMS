insert into itbp_clms.master_entity_type (id, entity_type)
values  (1, 'Brewery'),
        (2, 'Sub-Depot'),
        (3, 'Depot'),
        (5, 'Club'),
        (6, 'Consumer');