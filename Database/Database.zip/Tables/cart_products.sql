insert into itbp_clms.cart_products (id, cart_id, product_id, quantity, is_product_removed, created_by, creation_time)
values  (1, 1, 1, 20, 1, 2, '2021-10-26 09:21:52'),
        (2, 1, 2, 20, 1, 2, '2021-10-26 09:22:16');