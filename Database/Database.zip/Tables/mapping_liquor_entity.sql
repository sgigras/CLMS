insert into itbp_clms.mapping_liquor_entity (id, liquor_id, ml_id, entity_id, entity_type, minimum_order_quantity, sale_minimum_order_quantity, purchase_price, selling_price, minimun_order_type, single_piece_in_lot, city_id, state_id, creation_time, created_type, modification_time, modified_by)
values  (1, 1, null, 1, 2, null, null, null, null, null, null, 203, 26, null, null, null, null),
        (2, 1, null, 1, 2, null, null, null, null, null, null, 258, 26, null, null, null, null),
        (3, 1, null, 1, 2, null, null, null, null, null, null, 27, 27, null, null, null, null),
        (4, 1, null, 1, 2, null, null, null, null, null, null, 14, 3, null, null, null, null),
        (5, 2, null, 1, 2, null, null, null, null, null, null, 203, 26, null, null, null, null),
        (6, 2, null, 1, 2, null, null, null, null, null, null, 203, 26, null, null, null, null);