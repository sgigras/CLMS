insert into itbp_clms.liquor_description (id, liquor_description, liquor_image, liquor_brand_id, liquor_bottle_size_id, liquor_type_id, liquor_ml_id, creation_time, created_by, modification_time, modified_by, liquor_descriptioncol, brewery_id)
values  (7, 'Strong Premium', './liquor_image/20230105/kingfisherstrong3.jpg', '1', 2, '1', '17', '2023-01-23 15:53:21', 229, null, null, null, 1),
        (8, 'Number one Black Rare & Premium', './liquor_image/20230106/Force_Head_Quarter.png', '5', 2, '9', '1', '2023-01-23 15:55:51', 229, null, null, null, 1),
        (9, 'Blended Grape', './liquor_image/20230106/Bejois.png', '15', 2, '2', '1', '2023-01-23 15:57:16', 229, null, null, null, 1),
        (10, 'Royal Stag Deluxe', './liquor_image/20230106/ITBP_Logo.png', '7', 2, '9', '1', '2023-01-23 15:58:39', 229, null, null, null, 2),
        (11, ' the Legend Deluxe Premium Rum Very Old Vatted', './liquor_image/20230109/Old_Monk.jpg', '3', 2, '4', '1', '2023-01-23 15:59:50', 229, null, null, null, 2),
        (12, '100 Pipers Blended Deluxe Scotch Whisky', './liquor_image/20230109/Old_Monk-min.jpg', '7', 2, '9', '1', '2023-01-23 16:00:57', 229, null, null, null, 2);