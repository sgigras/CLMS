insert into itbp_clms.master_distributor_authority (id, distributor_authority, details_map_table, column_name)
values  (1, 'Brewery', 'master_brewery', 'brewery_name'),
        (2, 'Canteen', 'master_entities', 'entity_name'),
        (3, 'Stockist', null, null),
        (4, 'FHQ', null, null);